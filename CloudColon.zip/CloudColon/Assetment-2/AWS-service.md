### AWS Services and Rationale:

1. **AWS CloudFront**: Content Delivery Network (CDN) to ensure low latency and high transfer speeds globally.
2. **Amazon API Gateway**: Managed service to create, publish, maintain, monitor, and secure APIs.
3. **AWS WAF and Shield**: Protect the application from common web exploits and DDoS attacks.
4. **AWS Cognito**: Manage user sign-up, sign-in, and access control with OAuth support.
5. **Amazon EKS**: Run and scale Kubernetes applications in the cloud or on-premises.
6. **Amazon RDS**: Managed relational database service to handle user profiles and settings.
7. **AWS Lambda**: Serverless compute to handle integration with social media and e-commerce platforms.
8. **Amazon DynamoDB**: NoSQL database for high availability and low latency data access.
9. **Amazon S3**: Object storage for static content like images and videos.
10. **AWS CloudWatch**: Monitoring and observability service to collect and track metrics, log files, and set alarms.
11. **AWS Kinesis**: Collect, process, and analyze real-time streaming data.
12. **Amazon Redshift**: Data warehousing service for big data analytics.
13. **AWS CloudTrail**: Logs AWS account activity and API usage for auditing and compliance.
14. **Amazon Route 53**: Highly available and scalable cloud Domain Name System (DNS) web service.
15. **AWS ACM (AWS Certificate Manager)**: Provision, manage, and deploy SSL/TLS certificates for secure communication.

This high-level architecture ensures scalability, resilience, and security, meeting all the outlined functional requirements. For specific implementation details, further breakdown of microservices, and fine-tuning configurations would be required.