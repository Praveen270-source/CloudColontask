----> the high-level workflow diagram step by step:

### Step-by-Step Workflow Explanation

1. **User Interaction:**
   - **Users** access the application either through a web browser or mobile apps developed with React Native.

2. **Content Delivery:**
   - Requests from users are first routed through **AWS CloudFront**, a Content Delivery Network (CDN) that ensures low latency and high transfer speeds globally.

3. **Authentication:**
   - For authentication, users are redirected to **Google/Facebook OAuth Providers** for signing in or signing up using OAuth.
   - **AWS Cognito** manages the OAuth flow, handling user authentication and authorization, and integrates with the OAuth providers to facilitate user sign-in.

4. **API Gateway:**
   - Authenticated requests from users are forwarded to the **Amazon API Gateway**, which acts as the entry point for all API requests.
   - The API Gateway also handles rate limiting to prevent brute force attacks and ensures that all API calls use HTTPS for security.

5. **Web Application Firewall (WAF) and Shield:**
   - The **AWS WAF** filters incoming requests to block access from certain countries (e.g., Iraq and Somalia) and protect against common web exploits.
   - **AWS Shield** provides additional protection against DDoS attacks.

6. **Routing:**
   - **Amazon Route 53** is used for DNS routing, ensuring that user requests are directed to the appropriate services.

7. **Microservices:**
   - **Amazon EKS (Elastic Kubernetes Service)** runs the backend microservices, which are built using Java Spring Boot. These microservices handle various application logic and business processes, such as fetching and displaying celebrity profiles, filtering feeds, and aggregating social media activities.

8. **Data Storage:**
   - **Amazon RDS** (Relational Database Service) is used to store user settings and personal profiles.
   - **Amazon DynamoDB**, a NoSQL database, is used for session management and other data that requires low-latency access.
   - **Amazon S3** (Simple Storage Service) stores static content like images and videos.

9. **Data Aggregation:**
   - **AWS Lambda** functions aggregate data from various social media platforms (e.g., Facebook, Instagram, Twitter) and e-commerce sites (e.g., Etsy, StockX). These functions are triggered as needed to collect and process data.

10. **Monitoring and Logging:**
    - **Amazon CloudWatch** monitors application performance and sets up alerts for service disruptions or performance issues. It collects and tracks metrics, log files, and sets alarms.
    - **AWS CloudTrail** logs API calls and user activity within the AWS account for auditing and compliance purposes.

11. **Data Analytics:**
    - **Amazon Kinesis** streams data for real-time analytics.
    - **Amazon Redshift** is used for data warehousing, allowing for complex queries and data analysis on the aggregated data from various social platforms and e-commerce sites.


This workflow ensures a scalable, secure, and resilient application architecture that meets all functional requirements.